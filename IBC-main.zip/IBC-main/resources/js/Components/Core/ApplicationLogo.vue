<template>
    <img src="/images/ibc-group-logo.svg" alt="IBC Group Logo"/>
</template>
